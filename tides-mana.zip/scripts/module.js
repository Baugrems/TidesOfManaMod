import { NavalShipSheet } from "./ship-sheet.js";
import { MODULE_ID } from "./helpers.js";

Hooks.once("init", () => {
  console.log(`${MODULE_ID} | Initializing Tides of Mana: Naval Combat`);

  game.settings.register(MODULE_ID, "cannonPresets", {
    name: "Cannon Presets",
    scope: "world",
    config: false,
    type: Object,
    default: []
  });

  const actorTypes = game.system?.documentTypes?.Actor ?? [];
  const fallbackTypes = Object.keys(CONFIG.Actor?.typeLabels ?? {});
  const isDnd5e = game.system?.id === "dnd5e";
  const dnd5eTypes = ["character", "npc", "vehicle", "group"];
  const types = isDnd5e
    ? dnd5eTypes
    : actorTypes.length
      ? actorTypes
      : fallbackTypes.length
        ? fallbackTypes
        : ["character"];

  Actors.registerSheet(MODULE_ID, NavalShipSheet, {
    types,
    makeDefault: false,
    label: "Naval Ship"
  });
});
